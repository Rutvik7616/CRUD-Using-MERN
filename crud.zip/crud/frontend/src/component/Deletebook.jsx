import React from 'react'

const Deletebook = () => {
  return (
    <div>
      Deletebook
    </div>
  )
}

export default Deletebook
